# Sniper AI Trading Bot Package

Adds Sniper AI Mode:
- detects early breakout setups
- checks 5m/15m movement
- requires trend confirmation
- detects pullback-resume setups
- avoids overextended fake momentum
- gates buys before Turbo/Momentum can enter weak trades
- adds /sniper-ai/refresh endpoint
- adds Sniper AI dashboard panel

Install using the GitHub upload method from the project notes: extract the zip, upload the contents, then commit.
