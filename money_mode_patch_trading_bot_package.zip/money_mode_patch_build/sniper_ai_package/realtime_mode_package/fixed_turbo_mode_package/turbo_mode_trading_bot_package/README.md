# Turbo Mode Trading Bot Package

Built from the latest real bot package.

Adds Turbo Mode:
- requires strong Momentum Hunter score
- allows up to 8 active positions
- max 2 new buys per loop
- boosts size on strong momentum
- enables winner stacking
- cuts losers faster
- adds Turbo dashboard panel
- adds POST /turbo/check-exits safety endpoint

Deploy:
1. Upload to GitHub
2. Let Render redeploy
3. Let Vercel redeploy
4. Check Turbo Mode panel
