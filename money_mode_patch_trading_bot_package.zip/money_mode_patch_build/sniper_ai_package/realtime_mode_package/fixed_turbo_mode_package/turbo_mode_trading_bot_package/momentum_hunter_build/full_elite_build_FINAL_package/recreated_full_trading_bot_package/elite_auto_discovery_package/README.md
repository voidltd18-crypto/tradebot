# Elite Auto Discovery Package

Goal:
Reduce or avoid fallback usage by making discovery stronger.

Changes:
- Larger liquid seed pool
- More robust quote/trade fallback scoring
- Less brittle spread handling
- Better small-account scoring
- ETF/liquid leader backup candidates
- Fallback only after elite discovery tries to fill all 20

Dashboard still shows fallback count. Aim for:
Fully Discovered · 20/20 · 0 fallback

After deploy:
1. Push to GitHub
2. Let Render + Vercel redeploy
3. Press Refresh Weekly Universe
4. Check Auto Discovery Status
