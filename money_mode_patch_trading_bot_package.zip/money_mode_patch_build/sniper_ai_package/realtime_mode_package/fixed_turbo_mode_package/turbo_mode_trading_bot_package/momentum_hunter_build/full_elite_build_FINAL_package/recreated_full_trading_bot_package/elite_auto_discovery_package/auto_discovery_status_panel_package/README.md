# Auto Discovery Status Panel Package

Adds clear visibility for fallback usage.

Backend /status now includes:
- autoDiscovery.discoveredCount
- autoDiscovery.fallbackCount
- autoDiscovery.fallbackSymbols
- autoDiscovery.usingFallback
- autoDiscovery.fallbackOnly

Frontend adds:
- Auto Discovery Status panel
- Shows Fully Discovered or Fallback Used
- Shows discovered count and fallback symbols

After deploy:
1. Push to GitHub
2. Let Render + Vercel redeploy
3. Press Refresh Weekly Universe
4. Check Auto Discovery Status panel
