# Auto Discovery Render Crash Fixed Package

Fixes the Render crash:
NameError: discover_best_stocks is not defined

Cause:
The previous patch called discover_best_stocks() at module import time.

Fix:
- current_universe starts safely from SAFE_UNIVERSE fallback
- discover_best_stocks() is only called inside build_weekly_universe()
- SAFE_UNIVERSE is fallback only
- Auto discovery selects the best 20 from a broad seed pool using live quotes, spread and stock memory

After deploy:
1. Push to GitHub
2. Let Render redeploy
3. Open /status
4. Press Refresh Weekly Universe
