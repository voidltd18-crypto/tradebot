# Fixed Turbo Mode Package

Fixes:
- TURBO_MODE_ENABLED NameError on Render
- Turbo config is now defined before MAX_POSITIONS uses it

Upload to GitHub, then redeploy Render + Vercel.
