# Real-Time Mode Trading Bot Package

Adds background scan/cache refresh every 8 seconds, /realtime endpoint, and Real-Time Mode dashboard panel.
Buttons should feel faster because scan/market data is kept warm.
