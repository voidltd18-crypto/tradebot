# Money Mode Patch Package

Makes the bot less scared and more active:
- confidence floor 0.55
- good trades from 0.65+
- quality floor 0.012
- tiny negative momentum tolerated to -0.010
- Sniper/Turbo/Momentum thresholds relaxed to 6.2
- Money Mode dashboard panel
