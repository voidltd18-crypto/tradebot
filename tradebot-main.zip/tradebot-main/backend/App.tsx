
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";


function topFocusPercent(value: any) {
  return `${((Number(value) || 0) * 100).toFixed(2)}%`;
}

function getTopFocusCandidate(data: any) {
  const top = data?.topFocus?.top;
  if (top?.symbol) return top;

  const rows = Array.isArray(data?.autoUniverse?.rows) ? data.autoUniverse.rows : [];
  if (rows.length) {
    const sorted = [...rows].sort((a: any, b: any) => (Number(b?.score) || 0) - (Number(a?.score) || 0));
    return sorted[0] || null;
  }

  return null;
}

function TopFocusCard({ data }: { data: any }) {
  const top = getTopFocusCandidate(data);
  const queue = Array.isArray(data?.topFocus?.queue) ? data.topFocus.queue : [];
  const fallbackRows = Array.isArray(data?.autoUniverse?.rows)
    ? [...data.autoUniverse.rows].sort((a: any, b: any) => (Number(b?.score) || 0) - (Number(a?.score) || 0))
    : [];
  const nextRows = queue.length ? queue.slice(1, 5) : fallbackRows.slice(1, 5);

  return (
    <section className="panel" style={{ marginBottom: 18, borderColor: "rgba(250, 204, 21, 0.55)", background: "linear-gradient(135deg, rgba(250, 204, 21, 0.12), rgba(15, 23, 42, 0.92))" }}>
      <h2 style={{ margin: 0 }}>🏆 Top Focus Stock</h2>
      {top?.symbol ? (
        <>
          <div style={{ fontSize: 36, fontWeight: 900, marginTop: 8 }}>{top.symbol}</div>
          <div className="muted" style={{ marginTop: 6 }}>
            {top.confidence !== undefined ? <>Confidence <b>{topFocusPercent(top.confidence)}</b></> : <>Score <b>{Number(top.score || 0).toFixed(2)}</b></>}
            {top.qualityScore !== undefined ? <> · Quality <b>{Number(top.qualityScore || 0).toFixed(4)}</b></> : null}
            {top.price ? <> · Price <b>${Number(top.price || 0).toFixed(2)}</b></> : null}
          </div>
          {nextRows.length > 0 && (
            <div style={{ marginTop: 10, color: "#facc15", fontWeight: 800 }}>
              Next: {nextRows.map((r: any) => r.symbol).filter(Boolean).join(" → ")}
            </div>
          )}
        </>
      ) : (
        <div className="muted" style={{ marginTop: 8 }}>No focus candidate ready yet.</div>
      )}
    </section>
  );
}

const API_URL = import.meta.env.VITE_API_BASE || "https://tradebot-0myo.onrender.com";
const BOT_VERSION = "v1.1-strict-profit-mode";
type AnyObj = Record<string, any>;
type Tab = "overview" | "reports" | "positions" | "scanner" | "search" | "activity" | "admin";
type ViewMode = "simple" | "advanced" | "admin";

const usd = (n:any) => `$${Number(n || 0).toFixed(2)}`;
const gbp = (n:any) => `£${Number(n || 0).toFixed(2)}`;
const pct = (n:any) => `${Number(n || 0).toFixed(2)}%`;
const tone = (n:any) => Number(n || 0) >= 0 ? "gain" : "loss";

function Card({ title, children, wide=false }: {title?: string; children: React.ReactNode; wide?: boolean}) {
  return <section className={`card ${wide ? "wide" : ""}`}>{title && <h2>{title}</h2>}{children}</section>;
}
function Stat({ label, value, sub, className="" }: {label:string; value:React.ReactNode; sub?:React.ReactNode; className?:string}) {
  return <section className="card stat"><span>{label}</span><strong className={className}>{value}</strong>{sub && <small>{sub}</small>}</section>;
}

async function readJson(res: Response) {
  const text = await res.text();
  try {
    return text ? JSON.parse(text) : {};
  } catch {
    return { message: text };
  }
}

export default function App() {
  const [tab, setTab] = useState<Tab>("overview");
  const [viewMode, setViewMode] = useState<ViewMode>(() => {
    const saved = localStorage.getItem("tradebot_view_mode") as ViewMode | null;
    return saved === "advanced" || saved === "admin" || saved === "simple" ? saved : "simple";
  });
  const [data, setData] = useState<AnyObj>({});
  const [reports, setReports] = useState<AnyObj>({});
  
  const [authToken, setAuthToken] = useState<string>(() => localStorage.getItem("tradebot_auth_token") || "");
  const [secureUsername, setSecureUsername] = useState<string>("");
  const [securePassword, setSecurePassword] = useState<string>("");
  const [authError, setAuthError] = useState<string>("");
const [banking, setBanking] = useState<AnyObj>({});
  const [status, setStatus] = useState("Connecting...");
  const [message, setMessage] = useState("Ready.");
  const [apiKey, setApiKey] = useState(() => localStorage.getItem("dashboard_api_key") || "");
  const [selectedSymbol, setSelectedSymbol] = useState("");
  const [chartCurrency, setChartCurrency] = useState<"GBP"|"USD">("GBP");
  const [stockQuery, setStockQuery] = useState("");
  const [stockResults, setStockResults] = useState<any[]>([]);
  const [stockSearchLoading, setStockSearchLoading] = useState(false);
  const [tradingCapInput, setTradingCapInput] = useState<string>("");
  const [tradingCapSaving, setTradingCapSaving] = useState(false);
  const [replayCapInput, setReplayCapInput] = useState<string>("");
  const [replayLoading, setReplayLoading] = useState(false);
  const [replayResult, setReplayResult] = useState<AnyObj | null>(null);
  const [manualBaselineInput, setManualBaselineInput] = useState<string>("");
  const [baselineSaving, setBaselineSaving] = useState(false);
  const [strategyStrictness, setStrategyStrictness] = useState<number>(0);
  const [strategySaving, setStrategySaving] = useState(false);
  const [maxPositionsInput, setMaxPositionsInput] = useState<number>(6);
  const [buySizeMode, setBuySizeMode] = useState<"full"|"partial">("full");
  const [muskModeSaving, setMuskModeSaving] = useState(false);
  const [spacexHoldSaving, setSpacexHoldSaving] = useState(false);
  const [positionsSaving, setPositionsSaving] = useState(false);
  const fetchSeq = useRef(0);
  const fetchInFlight = useRef(false);
  const lastFetchAt = useRef(0);
  const POLL_MS = 10000;

  const rate = Number(data?.fx?.usdToGbp || 0.7403);
  const scans = Array.isArray(data?.scans) ? data.scans : [];
  const rawPositions = Array.isArray(data?.positions) ? data.positions : [];
  const positions = [...rawPositions].sort((a:AnyObj, b:AnyObj) => Number(b?.pnlPct || 0) - Number(a?.pnlPct || 0));
  const trades = Array.isArray(data?.trades) ? data.trades : [];
  const logs = Array.isArray(data?.logs) ? data.logs : [];
  const closedTrades = Array.isArray(reports?.closedTrades) ? reports.closedTrades : [];
  const equityHistory = Array.isArray(reports?.equityHistory) ? reports.equityHistory : (Array.isArray(data?.tradeTimeline) ? data.tradeTimeline : []);
  const bankingEnabled = Boolean(banking?.enabled || data?.banking?.enabled);
  const bankingCap = Number(banking?.maxTradingCapital ?? data?.banking?.maxTradingCapital ?? 0);
  const bankingCapGbp = Number(banking?.maxTradingCapitalGbp ?? data?.banking?.maxTradingCapitalGbp ?? bankingCap * rate);
  const bankingCapCurrency = String(banking?.tradingCapCurrency ?? data?.banking?.tradingCapCurrency ?? "USD");
  const bankingCapSource = String(banking?.tradingCapSource ?? data?.banking?.tradingCapSource ?? "env");
  const bankingEquity = Number(banking?.accountEquity ?? data?.banking?.accountEquity ?? data?.account?.equity ?? 0);
  const bankingEffective = Number(banking?.effectiveTradingEquity ?? data?.banking?.effectiveTradingEquity ?? 0);
  const bankingEffectiveGbp = Number(banking?.effectiveTradingEquityGbp ?? data?.banking?.effectiveTradingEquityGbp ?? bankingEffective * rate);
  const bankingBuffer = Number(banking?.bankedProfitCashBuffer ?? data?.banking?.bankedProfitCashBuffer ?? 0);
  const bankingBufferGbp = Number(banking?.bankedProfitCashBufferGbp ?? data?.banking?.bankedProfitCashBufferGbp ?? bankingBuffer * rate);
  const dynamicScanner = data?.dynamicMarketScanner || data?.autoUniverse?.dynamicScanner || {};
  const dynamicRows = Array.isArray(dynamicScanner?.rows) ? dynamicScanner.rows : [];
  const dynamicPickCount = Number(data?.autoUniverse?.dynamicPickCount || dynamicRows.length || 0);
  const muskMode = data?.muskMode || data?.autoUniverse?.muskMode || {};
  const muskModeOn = Boolean(muskMode?.enabled);
  const spaceXHold = data?.spaceXHold || data?.autoUniverse?.spaceXHold || muskMode?.spaceXHold || {};
  const spaceXHoldOn = Boolean(spaceXHold?.enabled);
  const strategySettings = data?.strategySettings || {};
  const positionSettings = data?.positionSettings || {};
  const strictnessLabels = ["Safe", "Balanced", "Aggressive"];
  const strictnessLabel = strictnessLabels[Math.max(0, Math.min(2, Number(strategyStrictness || 0)))] || "Safe";

  useEffect(() => {
    const gbpCap = Number(banking?.maxTradingCapitalGbp ?? data?.banking?.maxTradingCapitalGbp ?? 0);
    if (gbpCap > 0 && !tradingCapInput) setTradingCapInput(String(Math.round(gbpCap)));
    if (gbpCap > 0 && !replayCapInput) setReplayCapInput(String(Math.round(gbpCap)));
  }, [banking?.maxTradingCapitalGbp, data?.banking?.maxTradingCapitalGbp]);

  useEffect(() => {
    const level = Number(data?.strategySettings?.level);
    if (Number.isFinite(level)) setStrategyStrictness(Math.max(0, Math.min(2, level)));
  }, [data?.strategySettings?.level]);

  useEffect(() => {
    const maxPos = Number(data?.positionSettings?.maxPositions ?? data?.maxPositions ?? data?.config?.maxPositions);
    if (Number.isFinite(maxPos) && maxPos > 0) setMaxPositionsInput(Math.max(1, Math.min(10, maxPos)));
  }, [data?.positionSettings?.maxPositions, data?.maxPositions, data?.config?.maxPositions]);

  
  const token = authToken || apiKey.trim();
  const secureHeaders = token ? { "X-Auth-Token": token, "x-api-key": token } : {};

  async function triggerDynamicMarketUniverseRefresh(loginToken: string, reason = "login") {
    if (!loginToken) return;
    try {
      setMessage(reason === "login" ? "Login successful. Refreshing dynamic market universe..." : "Refreshing dynamic market universe...");
      const res = await fetch(`${API_URL}/refresh-universe`, {
        method: "POST",
        headers: { "X-Auth-Token": loginToken, "x-api-key": loginToken },
        cache: "no-store",
      });
      const json = await readJson(res);
      if (!res.ok || json?.ok === false) throw new Error(json?.detail || json?.message || "Dynamic market refresh failed");

      const autoUniverse = json?.autoUniverse || json;
      const dynamicScanner = json?.dynamicMarketScanner || autoUniverse?.dynamicScanner;
      setData(prev => ({
        ...prev,
        autoUniverse: autoUniverse?.activeSymbols || autoUniverse?.rows ? autoUniverse : prev.autoUniverse,
        universe: autoUniverse?.activeSymbols || json?.activeSymbols || prev.universe,
        dynamicMarketScanner: dynamicScanner || prev.dynamicMarketScanner,
        lastAction: json?.message || "Dynamic market universe refreshed",
        lastActionAt: new Date().toISOString(),
      }));
      setMessage(json?.message || "Dynamic market universe refreshed.");
    } catch (e:any) {
      setMessage(e?.message || "Dynamic market refresh failed. Dashboard will still load normally.");
    }
  }

  async function secureLogin() {
    try {
      setAuthError("");
      const res = await fetch(`${API_URL}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: secureUsername.trim(), password: securePassword }),
      });
      const json = await readJson(res);
      if (!res.ok || !json?.token) throw new Error(json?.detail || "Login failed");
      localStorage.setItem("tradebot_auth_token", json.token);
      localStorage.setItem("dashboard_api_key", json.token);
      setAuthToken(json.token);
      setApiKey(json.token);
      setSecurePassword("");
      setTimeout(() => triggerDynamicMarketUniverseRefresh(json.token, "login"), 150);
    } catch (e: any) {
      setAuthError(e?.message || "Login failed");
    }
  }

  function secureLogout() {
    localStorage.removeItem("tradebot_auth_token");
    localStorage.removeItem("dashboard_api_key");
    fetchSeq.current += 1;
    fetchInFlight.current = false;
    lastFetchAt.current = 0;
    setAuthToken("");
    setApiKey("");
    setData({});
    setReports({});
    setBanking({});
    setMessage("Logged out.");
    setStatus("Logged out");
    setTab("overview");
    setSelectedSymbol("");
    setStockQuery("");
    setStockResults([]);
    setReplayResult(null);
    setReplayLoading(false);
  }

const fetchData = useCallback(async (force = false) => {
    if (!authToken) return;

    const now = Date.now();
    if (!force && (fetchInFlight.current || now - lastFetchAt.current < POLL_MS)) return;

    fetchInFlight.current = true;
    lastFetchAt.current = now;
    const seq = ++fetchSeq.current;
    try {
      const [statusRes, reportRes, bankingRes, marketRes, buySizeRes] = await Promise.allSettled([
        fetch(`${API_URL}/status`, { cache: "no-store", headers: secureHeaders }).then(readJson),
        fetch(`${API_URL}/reports`, { cache: "no-store", headers: secureHeaders }).then(readJson),
        fetch(`${API_URL}/banking-status`, { cache: "no-store", headers: secureHeaders }).then(readJson),
        fetch(`${API_URL}/market-status`, { cache: "no-store", headers: secureHeaders }).then(readJson),
        fetch(`${API_URL}/buy-size-mode`, { cache: "no-store", headers: secureHeaders }).then(readJson),
      ]);

      if (seq !== fetchSeq.current) return;

      if (statusRes.status === "fulfilled") {
        const json = statusRes.value;
        if (json && typeof json === "object") {
          setData(prev => ({ ...prev, ...json }));
          if (json?.positionSettings?.buySizeMode) {
            setBuySizeMode(json.positionSettings.buySizeMode === "partial" ? "partial" : "full");
          }
        }
        const nextScans = Array.isArray(json?.scans) ? json.scans : [];
        if (!selectedSymbol && nextScans.length) setSelectedSymbol(nextScans[0].symbol);
      }

      if (reportRes.status === "fulfilled" && reportRes.value) {
        setReports(prev => ({ ...prev, ...reportRes.value }));
      }

      if (bankingRes.status === "fulfilled" && bankingRes.value) {
        setBanking(bankingRes.value || {});
      }

      if (marketRes.status === "fulfilled" && marketRes.value?.market) {
        setData(prev => ({ ...prev, market: marketRes.value.market }));
      }

      if (buySizeRes.status === "fulfilled" && buySizeRes.value) {
        const mode = buySizeRes.value.buySizeMode === "partial" ? "partial" : "full";
        setBuySizeMode(mode);
        setData(prev => ({
          ...prev,
          buySizePreview: buySizeRes.value.preview || prev.buySizePreview,
          positionSettings: {
            ...(prev.positionSettings || {}),
            buySizeMode: mode,
            fullBuyWhenOnePosition: mode === "full",
            buySizePreview: buySizeRes.value.preview || prev.positionSettings?.buySizePreview,
          },
        }));
      }

      setStatus("Connected");
    } catch (e) {
      console.error(e);
      setStatus("Connection failed");
    } finally {
      fetchInFlight.current = false;
    }
  }, [authToken, selectedSymbol]);

  useEffect(() => {
    if (!authToken) return;
    fetchData(true);
    const i = setInterval(() => fetchData(false), POLL_MS);
    return () => clearInterval(i);
  }, [authToken, fetchData]);

  useEffect(() => {
    if (!authToken) return;

    let warnedForDate = "";

    const scheduleMidnightLogout = () => {
      const now = new Date();
      const nextMidnight = new Date(now);
      nextMidnight.setHours(24, 0, 0, 0);
      const msUntilMidnight = Math.max(1000, nextMidnight.getTime() - now.getTime());
      const msUntilWarning = Math.max(1000, msUntilMidnight - 60000);

      const warningTimer = window.setTimeout(() => {
        const todayKey = new Date().toISOString().slice(0, 10);
        if (warnedForDate !== todayKey) {
          warnedForDate = todayKey;
          setMessage("Daily session reset soon. You will be logged out at 00:00.");
        }
      }, msUntilWarning);

      const logoutTimer = window.setTimeout(() => {
        setMessage("00:00 daily session reset. Logging out...");
        secureLogout();
      }, msUntilMidnight + 500);

      return () => {
        window.clearTimeout(warningTimer);
        window.clearTimeout(logoutTimer);
      };
    };

    return scheduleMidnightLogout();
  }, [authToken]);



  function saveApiKey() {
    localStorage.setItem("dashboard_api_key", apiKey);
    setMessage("Dashboard password saved.");
  }

  async function refreshWeeklyUniverseView() {
    try {
      const res = await fetch(`${API_URL}/weekly-universe`, {
        cache: "no-store",
        headers: secureHeaders,
      });
      const json = await readJson(res);
      const autoUniverse = json?.autoUniverse || json;
      if (autoUniverse?.activeSymbols || autoUniverse?.rows) {
        setData(prev => ({
          ...prev,
          autoUniverse,
          universe: autoUniverse.activeSymbols || prev.universe,
          lastAction: json?.message || "Dynamic universe refreshed",
          lastActionAt: new Date().toISOString(),
        }));
      }
    } catch (e) {
      console.error("Weekly universe follow-up failed", e);
    }
  }

  async function action(endpoint:string) {
    if (!token) {
      setMessage("Please login first.");
      return;
    }

    const optimistic = endpoint === "/pause"
      ? (prev: AnyObj) => ({ ...prev, botEnabled: false })
      : endpoint === "/resume"
        ? (prev: AnyObj) => ({ ...prev, botEnabled: true })
        : null;

    if (optimistic) setData(optimistic);

    const isWeeklyRefresh = endpoint === "/refresh-universe";
    setMessage(isWeeklyRefresh ? "Dynamic market refresh sent. Updating universe..." : `Sent ${endpoint}. Updating dashboard...`);

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), isWeeklyRefresh ? 12000 : 30000);

    try {
      const res = await fetch(`${API_URL}${endpoint}`, {
        method:"POST",
        headers: secureHeaders,
        cache: "no-store",
        signal: controller.signal,
      });
      const json = await readJson(res);
      if (!res.ok) throw new Error(json?.detail || json?.message || `Action failed (${res.status})`);

      if (isWeeklyRefresh) {
        const autoUniverse = json?.autoUniverse;
        if (autoUniverse?.activeSymbols || autoUniverse?.rows) {
          setData(prev => ({
            ...prev,
            autoUniverse,
            universe: autoUniverse.activeSymbols || prev.universe,
            lastAction: json?.message || "Dynamic universe refreshed",
            lastActionAt: new Date().toISOString(),
          }));
        }
        setMessage(json?.message || "Dynamic universe refreshed.");
        await refreshWeeklyUniverseView();
      } else {
        setMessage(json.message || json.detail || JSON.stringify(json));
      }
    } catch (e:any) {
      if (isWeeklyRefresh && e?.name === "AbortError") {
        setMessage("Dynamic refresh was sent. Checking saved universe now...");
        await refreshWeeklyUniverseView();
      } else {
        setMessage(e?.name === "AbortError" ? "Action is still processing on Render. Dashboard will refresh normally." : (e?.message || "Action failed."));
      }
    } finally {
      clearTimeout(timeout);
      await fetchData(true);
      if (isWeeklyRefresh) setTimeout(() => refreshWeeklyUniverseView(), 2500);
    }
  }

  async function searchStocks(queryOverride?: string) {
    const query = (queryOverride ?? stockQuery).trim();
    if (!query) { setStockResults([]); return; }
    setStockSearchLoading(true);
    try {
      const res = await fetch(`${API_URL}/search-stocks?q=${encodeURIComponent(query)}`, { cache: "no-store", headers: secureHeaders });
      const json = await readJson(res);
      setStockResults(Array.isArray(json.results) ? json.results : []);
    } catch {
      setMessage("Stock search failed.");
    } finally {
      setStockSearchLoading(false);
    }
  }

  async function saveTradingCap(capOverride?: number) {
    if (!token) {
      setMessage("Please login first.");
      return;
    }

    const capGbp = Number(capOverride ?? tradingCapInput);
    if (!Number.isFinite(capGbp) || capGbp <= 0) {
      setMessage("Enter a valid trading cap in GBP.");
      return;
    }

    setTradingCapSaving(true);
    setMessage(`Saving trading cap at £${capGbp.toFixed(2)}...`);

    try {
      const res = await fetch(`${API_URL}/trading-cap`, {
        method: "POST",
        headers: { ...secureHeaders, "Content-Type": "application/json" },
        cache: "no-store",
        body: JSON.stringify({ capGbp, currency: "GBP" }),
      });
      const json = await readJson(res);
      if (!res.ok || json?.ok === false) throw new Error(json?.detail || json?.message || "Could not save trading cap");
      setBanking(json || {});
      setData(prev => ({ ...prev, banking: json, newPositionNotional: json?.newPositionNotional ?? prev.newPositionNotional }));
      setTradingCapInput(String(Math.round(Number(json?.maxTradingCapitalGbp || capGbp))));
      setMessage(json?.message || "Trading cap saved.");
      await fetchData(true);
    } catch (e:any) {
      setMessage(e?.message || "Could not save trading cap.");
    } finally {
      setTradingCapSaving(false);
    }
  }

  async function saveStrategyStrictness(levelOverride?: number) {
    if (!token) {
      setMessage("Please login first.");
      return;
    }

    const level = Math.max(0, Math.min(2, Number(levelOverride ?? strategyStrictness ?? 0)));
    const preset = level <= 0 ? "safe" : level >= 2 ? "aggressive" : "balanced";

    setStrategySaving(true);
    setMessage(`Saving trading strictness: ${strictnessLabels[level]}...`);

    try {
      const res = await fetch(`${API_URL}/strategy-settings`, {
        method: "POST",
        headers: { ...secureHeaders, "Content-Type": "application/json" },
        cache: "no-store",
        body: JSON.stringify({ level, preset }),
      });
      const json = await readJson(res);
      if (!res.ok || json?.ok === false) throw new Error(json?.detail || json?.message || "Could not save trading strictness");
      setStrategyStrictness(level);
      setData(prev => ({ ...prev, strategySettings: json, aPlusMinConfidence: json?.aPlusMinConfidence ?? prev.aPlusMinConfidence }));
      setMessage(json?.message || `Trading strictness set to ${strictnessLabels[level]}.`);
      await fetchData(true);
    } catch (e:any) {
      setMessage(e?.message || "Could not save trading strictness.");
    } finally {
      setStrategySaving(false);
    }
  }

  async function saveMaxPositions(valueOverride?: number) {
    if (!token) {
      setMessage("Please login first.");
      return;
    }

    const value = Math.max(1, Math.min(10, Number(valueOverride ?? maxPositionsInput ?? 6)));

    setPositionsSaving(true);
    setMessage(`Saving max positions: ${value}...`);

    try {
      const res = await fetch(`${API_URL}/position-settings`, {
        method: "POST",
        headers: { ...secureHeaders, "Content-Type": "application/json" },
        cache: "no-store",
        body: JSON.stringify({ maxPositions: value }),
      });
      const json = await readJson(res);
      if (!res.ok || json?.ok === false) throw new Error(json?.detail || json?.message || "Could not save max positions");
      setMaxPositionsInput(Number(json?.maxPositions || value));
      setData(prev => ({ ...prev, positionSettings: json, maxPositions: json?.maxPositions ?? value }));
      setMessage(json?.message || `Max positions set to ${value}.`);
      await fetchData(true);
    } catch (e:any) {
      setMessage(e?.message || "Could not save max positions.");
    } finally {
      setPositionsSaving(false);
    }
  }



  async function saveBuySizeMode(mode:"full"|"partial") {
    if (!token) {
      setMessage("Please login first.");
      return;
    }
    try {
      setMessage(`Saving ${mode === "full" ? "Full Buy" : "Partial Buy"} mode...`);
      const res = await fetch(`${API_URL}/buy-size-mode`, {
        method: "POST",
        headers: { ...secureHeaders, "Content-Type": "application/json" },
        cache: "no-store",
        body: JSON.stringify({ mode }),
      });
      const json = await readJson(res);
      if (!res.ok || json?.ok === false) throw new Error(json?.detail || json?.message || "Could not save buy size mode");
      const savedMode = json?.buySizeMode === "partial" ? "partial" : "full";
      setBuySizeMode(savedMode);
      setData(prev => ({
        ...prev,
        positionSettings: { ...(prev.positionSettings || {}), ...(json.positionSettings || {}), buySizeMode: savedMode, fullBuyWhenOnePosition: savedMode === "full", buySizePreview: json.preview || json.buySizePreview || prev.positionSettings?.buySizePreview },
        buySizePreview: json.preview || json.buySizePreview || prev.buySizePreview,
      }));
      setMessage(json?.message || `Buy size mode saved as ${savedMode}.`);
      await fetchData(true);
    } catch (e:any) {
      setMessage(e?.message || "Could not save buy size mode.");
    }
  }
  async function saveMuskMode(enabled:boolean) {
    if (!token) {
      setMessage("Please login first.");
      return;
    }
    setMuskModeSaving(true);
    setMessage(enabled ? "Switching Musk Mode ON..." : "Switching Musk Mode OFF...");
    try {
      const res = await fetch(`${API_URL}/musk-mode`, {
        method: "POST",
        headers: { ...secureHeaders, "Content-Type": "application/json" },
        cache: "no-store",
        body: JSON.stringify({ enabled }),
      });
      const json = await readJson(res);
      if (!res.ok || json?.ok === false) throw new Error(json?.detail || json?.message || "Could not save Musk Mode");
      setData(prev => ({
        ...prev,
        muskMode: json,
        autoUniverse: json?.autoUniverse?.activeSymbols || json?.autoUniverse?.rows ? json.autoUniverse : prev.autoUniverse,
        universe: json?.activeSymbols || json?.autoUniverse?.activeSymbols || prev.universe,
        lastAction: json?.message || (enabled ? "Musk Mode ON" : "Musk Mode OFF"),
        lastActionAt: new Date().toISOString(),
      }));
      setMessage(json?.message || (enabled ? "Musk Mode ON." : "Musk Mode OFF."));
      await fetchData(true);
    } catch (e:any) {
      setMessage(e?.message || "Could not save Musk Mode.");
    } finally {
      setMuskModeSaving(false);
    }
  }

  async function saveSpaceXHold(enabled:boolean) {
    if (!token) {
      setMessage("Please login first.");
      return;
    }
    setSpacexHoldSaving(true);
    setMessage(enabled ? "Switching Musk hold ON..." : "Switching Musk hold OFF...");
    try {
      const res = await fetch(`${API_URL}/spacex-hold`, {
        method: "POST",
        headers: { ...secureHeaders, "Content-Type": "application/json" },
        cache: "no-store",
        body: JSON.stringify({ enabled }),
      });
      const json = await readJson(res);
      if (!res.ok || json?.ok === false) throw new Error(json?.detail || json?.message || "Could not save Musk hold");
      setData(prev => ({
        ...prev,
        spaceXHold: json,
        lastAction: json?.message || (enabled ? "Musk hold ON" : "Musk hold OFF"),
        lastActionAt: new Date().toISOString(),
      }));
      setMessage(json?.message || (enabled ? "Musk hold ON." : "Musk hold OFF."));
      await fetchData(true);
    } catch (e:any) {
      setMessage(e?.message || "Could not save Musk hold.");
    } finally {
      setSpacexHoldSaving(false);
    }
  }


  async function refreshDynamicScanner() {
    if (!token) {
      setMessage("Please login first.");
      return;
    }
    setMessage("Refreshing dynamic market universe...");
    try {
      const res = await fetch(`${API_URL}/refresh-universe`, {
        method: "POST",
        headers: secureHeaders,
        cache: "no-store",
      });
      const json = await readJson(res);
      if (!res.ok || json?.ok === false) throw new Error(json?.detail || json?.message || "Dynamic market refresh failed");
      const autoUniverse = json?.autoUniverse || json;
      const dynamicScanner = json?.dynamicMarketScanner || autoUniverse?.dynamicScanner;
      setData(prev => ({
        ...prev,
        autoUniverse: autoUniverse?.activeSymbols || autoUniverse?.rows ? autoUniverse : prev.autoUniverse,
        universe: autoUniverse?.activeSymbols || json?.activeSymbols || prev.universe,
        dynamicMarketScanner: dynamicScanner || prev.dynamicMarketScanner,
        lastAction: json?.message || "Dynamic market universe refreshed",
        lastActionAt: new Date().toISOString(),
      }));
      setMessage(json?.message || "Dynamic market universe refreshed.");
      await refreshWeeklyUniverseView();
      await fetchData(true);
    } catch (e:any) {
      setMessage(e?.message || "Dynamic market refresh failed.");
    }
  }

  async function runBacktestReplay() {
    if (!token) {
      setMessage("Please login first.");
      return;
    }

    const capGbp = Number(replayCapInput || tradingCapInput || bankingCapGbp || 0);
    if (!Number.isFinite(capGbp) || capGbp <= 0) {
      setMessage("Enter a valid replay cap in GBP.");
      return;
    }

    setReplayLoading(true);
    setMessage(`Running paper replay using £${capGbp.toFixed(2)} cap...`);
    try {
      const res = await fetch(`${API_URL}/backtest-replay`, {
        method: "POST",
        headers: { ...secureHeaders, "Content-Type": "application/json" },
        cache: "no-store",
        body: JSON.stringify({ capGbp }),
      });
      const json = await readJson(res);
      if (!res.ok || json?.ok === false) throw new Error(json?.detail || json?.message || "Replay failed");
      setReplayResult(json);
      setMessage(json?.message || "Backtest / paper replay complete.");
    } catch (e:any) {
      setMessage(e?.message || "Replay failed.");
    } finally {
      setReplayLoading(false);
    }
  }

  async function setManualBaseline() {
    if (!token) {
      setMessage("Please login first.");
      return;
    }

    const gbpValue = Number(manualBaselineInput);
    if (!Number.isFinite(gbpValue) || gbpValue <= 0) {
      setMessage("Enter a valid GBP baseline value.");
      return;
    }

    const fx = Number(data?.fx?.usdToGbp || 0.745);
    const usdValue = fx > 0 ? gbpValue / fx : gbpValue;

    setBaselineSaving(true);
    setMessage(`Setting baseline to £${gbpValue.toFixed(2)}...`);

    try {
      const res = await fetch(`${API_URL}/set-baseline`, {
        method: "POST",
        headers: { ...secureHeaders, "Content-Type": "application/json" },
        cache: "no-store",
        body: JSON.stringify({ baseline: usdValue }),
      });
      const json = await readJson(res);
      if (!res.ok || json?.ok === false) throw new Error(json?.detail || json?.message || "Could not set baseline");

      setMessage(`Baseline set to about £${gbpValue.toFixed(2)}.`);
      await fetchReports();
      await fetchData(true);
    } catch (e:any) {
      setMessage(e?.message || "Could not set baseline.");
    } finally {
      setBaselineSaving(false);
    }
  }

  async function resetBaseline() {
    if (!confirm("Reset PnL baseline to current equity? This only resets reporting.")) return;
    await action("/reset-baseline");
  }

  function chartLabel(raw:any, i:number) {
    const d = new Date(raw || "");
    if (Number.isNaN(d.getTime())) return raw ? String(raw).slice(0,16) : `#${i+1}`;
    return d.toLocaleString(undefined, { month:"short", day:"2-digit", hour:"2-digit", minute:"2-digit" });
  }
  function chartDay(raw:any, i:number) {
    const d = new Date(raw || "");
    if (Number.isNaN(d.getTime())) return raw ? String(raw).slice(0,10) : `Session ${i+1}`;
    return d.toLocaleDateString(undefined, { month:"short", day:"2-digit" });
  }

  const reportChart = useMemo(() => equityHistory.map((e:AnyObj, i:number) => {
    const raw = e.time || e.timestamp || e.t || e.label || "";
    return {
      idx:i,
      label:chartLabel(raw,i),
      day:chartDay(raw,i),
      equity: chartCurrency === "GBP" ? Number(e.equityGbp ?? e.valueGbp ?? Number(e.equity || e.value || 0) * rate) : Number(e.equity ?? e.value ?? 0),
      pnl: chartCurrency === "GBP" ? Number(e.pnlGbp ?? Number(e.pnl || 0) * rate) : Number(e.pnl || 0)
    };
  }), [equityHistory, chartCurrency, rate]);

  const dailyPnlChart = useMemo(() => {
    const grouped: Record<string, number> = {};
    for (const p of reportChart) grouped[p.day] = (grouped[p.day] || 0) + Number(p.pnl || 0);
    return Object.entries(grouped).map(([day,pnl]) => ({ day, pnl }));
  }, [reportChart]);

  const selectedScan = scans.find((s:AnyObj) => s.symbol === selectedSymbol) || scans[0];
  const scannerChart = selectedScan?.priceCurve || [];
  const totalDeposited = Number(reports.totalDeposited ?? 0);
  const earned = Number(reports.earnedSinceDeposit ?? 0);
  const totalGainLoss = Number(reports.totalGainLoss ?? 0);
  const lost = Number(reports.lostSinceDeposit ?? 0);
  const tabs: Tab[] = useMemo(() => {
    if (viewMode === "simple") return ["overview", "positions", "search"];
    if (viewMode === "advanced") return ["overview", "reports", "positions", "scanner", "search", "activity"];
    return ["overview", "reports", "positions", "scanner", "search", "activity", "admin"];
  }, [viewMode]);
  const simpleView = viewMode === "simple";


  function positionGlowStyle(position: AnyObj): React.CSSProperties {
    const pnlPct = Number(position?.pnlPct || 0);

    if (pnlPct >= 5) {
      return {
        borderColor: "rgba(34, 197, 94, 0.95)",
        boxShadow: "0 0 26px rgba(34, 197, 94, 0.42), inset 0 0 18px rgba(34, 197, 94, 0.08)",
        background: "linear-gradient(135deg, rgba(34,197,94,0.13), rgba(2,6,23,0.96) 55%)"
      };
    }

    if (pnlPct >= 1) {
      return {
        borderColor: "rgba(34, 197, 94, 0.65)",
        boxShadow: "0 0 18px rgba(34, 197, 94, 0.25), inset 0 0 14px rgba(34, 197, 94, 0.06)",
        background: "linear-gradient(135deg, rgba(34,197,94,0.08), rgba(2,6,23,0.96) 55%)"
      };
    }

    if (pnlPct > -1) {
      return {
        borderColor: "rgba(56, 189, 248, 0.35)",
        boxShadow: "0 0 12px rgba(56, 189, 248, 0.10)"
      };
    }

    if (pnlPct > -4) {
      return {
        borderColor: "rgba(251, 146, 60, 0.75)",
        boxShadow: "0 0 20px rgba(251, 146, 60, 0.28), inset 0 0 14px rgba(251, 146, 60, 0.06)",
        background: "linear-gradient(135deg, rgba(251,146,60,0.10), rgba(2,6,23,0.96) 55%)"
      };
    }

    return {
      borderColor: "rgba(248, 113, 113, 0.9)",
      boxShadow: "0 0 28px rgba(248, 113, 113, 0.38), inset 0 0 18px rgba(248, 113, 113, 0.08)",
      background: "linear-gradient(135deg, rgba(248,113,113,0.13), rgba(2,6,23,0.96) 55%)"
    };
  }
  function changeViewMode(mode: ViewMode) {
    setViewMode(mode);
    localStorage.setItem("tradebot_view_mode", mode);
    const allowed: Record<ViewMode, Tab[]> = {
      simple: ["overview", "positions", "search"],
      advanced: ["overview", "reports", "positions", "scanner", "search", "activity"],
      admin: ["overview", "reports", "positions", "scanner", "search", "activity", "admin"],
    };
    if (!allowed[mode].includes(tab)) setTab("overview");
  }

  if (!authToken) {
    return (
      <div className="app">
        <h1>TradeBot Secure Login</h1>
        <div className="card" style={{ maxWidth: 520, margin: "40px auto" }}>
          <h2>Login</h2>
          <p className="muted">Enter your admin username and password.</p>
          <input
            value={secureUsername}
            onChange={(e) => setSecureUsername(e.target.value)}
            placeholder="Username"
            style={{ width: "100%", padding: "14px", borderRadius: "12px", marginBottom: "12px" }}
          />
          <input
            type="password"
            value={securePassword}
            onChange={(e) => setSecurePassword(e.target.value)}
            placeholder="Password"
            style={{ width: "100%", padding: "14px", borderRadius: "12px", marginBottom: "12px" }}
            onKeyDown={(e) => { if (e.key === "Enter") secureLogin(); }}
          />
          <button onClick={secureLogin}>Login</button>
          {authError && <p className="loss">{authError}</p>}
        </div>
      </div>
    );
  }

  return <div className="app">

      <style>{`
        /* REPORTS_FINAL_STABLE_DARK */
        .reports-page { background:#070b18 !important; color:#eaf1ff !important; min-height:100vh !important; }
        .reports-page .card, .reports-page section { background:#11182a !important; color:#eaf1ff !important; border-color:#26324a !important; }
        .reports-page input, .reports-page select, .reports-page table, .reports-page thead, .reports-page tbody, .reports-page tr, .reports-page td, .reports-page th { background:#070b18 !important; color:#eaf1ff !important; border-color:#26324a !important; }
        .reports-page .muted { color:#9aa7bd !important; }
      `}</style>


      <style>{`
        /* REPORTS_FORCE_DARK_FINAL_SAFE */
        .reports-page{background:#070b18!important;color:#eaf1ff!important;min-height:100vh!important;}
        .reports-page .card,.reports-page section{background:#11182a!important;color:#eaf1ff!important;border-color:#26324a!important;}
        .reports-page input,.reports-page select,.reports-page table,.reports-page td,.reports-page th{background:#070b18!important;color:#eaf1ff!important;border-color:#26324a!important;}
        .reports-page .muted{color:#9aa7bd!important;}
      `}</style>

    <header className="topbar">
      <div><p className="eyebrow">Rebuilt Sniper Profit Bot</p><h1>TradeBot</h1></div>
      <div className="pills">
        <span className="pill ok">{status}</span>
        <span className={`pill ${data?.market?.isOpen ? "ok" : data?.market?.isExtendedHours ? "ok" : "warn"}`}>Market {data?.market?.label || "UNKNOWN"}</span>
        <span className={`pill ${data?.botEnabled ? "ok" : "bad"}`}>Bot {data?.botEnabled ? "ON" : "OFF"}</span>
        <span className="pill">{data?.paperMode ? "PAPER" : "LIVE"}</span>
        <button
          onClick={secureLogout}
          className="ghost"
          style={{ padding: "10px 14px", borderRadius: "999px", fontSize: "14px" }}
        >
          Logout
        </button>
      </div>
    </header>

    <TopFocusCard data={data} />

    <section className="stats">
      <Stat label="Equity" value={gbp(Number(data?.account?.equity || 0) * rate)} sub={usd(data?.account?.equity)} />
      <Stat label="Buying Power" value={gbp(Number(data?.account?.buyingPower || 0) * rate)} sub={usd(data?.account?.buyingPower)} />
      <Stat label="Day PnL" value={gbp(Number(data?.account?.pnlDay || 0) * rate)} sub={usd(data?.account?.pnlDay)} className={tone(data?.account?.pnlDay)} />
      <Stat label="Total Gain/Loss" value={gbp(totalGainLoss * rate)} sub={`Deposited ${gbp(totalDeposited * rate)} / ${usd(totalDeposited)}`} className={tone(totalGainLoss)} />
    </section>

    <nav className="tabs mode-tabs" aria-label="Dashboard mode">
      <button className={viewMode==="simple" ? "active":""} onClick={() => changeViewMode("simple")}>SIMPLE VIEW</button>
      <button className={viewMode==="advanced" ? "active":""} onClick={() => changeViewMode("advanced")}>ADVANCED VIEW</button>
      <button className={viewMode==="admin" ? "active":""} onClick={() => changeViewMode("admin")}>ADMIN VIEW</button>
    </nav>

    <nav className="tabs">{tabs.map(t => <button key={t} className={tab===t ? "active":""} onClick={() => setTab(t)}>{t.toUpperCase()}</button>)}</nav>

    {tab==="overview" && <main className="grid two">
      {simpleView && <Card title="Simple View" wide><p className="muted">Showing only the essentials. Switch to Advanced View for scanner, universe, reports and logs, or Admin View for settings.</p></Card>}
      <Card title="Market Session" wide>
        <div className="summary">
          <div><span>Status</span><b className={data?.market?.isOpen || data?.market?.isExtendedHours ? "gain" : ""}>{data?.market?.label || "UNKNOWN"}</b></div>
          <div><span>Session</span><b>{String(data?.market?.session || "unknown").replace("_", " ")}</b></div>
          <div><span>Next open</span><b>{data?.market?.nextOpen ? new Date(data.market.nextOpen).toLocaleString() : "—"}</b></div>
          <div><span>Next close</span><b>{data?.market?.nextClose ? new Date(data.market.nextClose).toLocaleString() : "—"}</b></div>
        </div>
        <p className="muted">Pre-market and after-hours are shown separately. Auto buys still follow the backend trade rules.</p>
      </Card>
      <Card title="Controls"><div className="actions">
        <button onClick={() => fetchData(true)}>Refresh Data</button>
        <button onClick={() => action("/manual-buy")}>Money Buy</button>
        <button className="danger" onClick={() => action("/manual-sell")}>Sell Worst</button>
        <button className="purple" onClick={() => action("/refresh-universe")}>↻ Dynamic Market Refresh</button>
        <button className="ghost" onClick={() => action("/pause")}>Pause</button>
        <button onClick={() => action("/resume")}>Resume</button>
      </div><p className="notice">{message}</p></Card>
      <Card title="Live Summary"><div className="summary">
        <div><span>Positions</span><b>{positions.length}/{data?.maxPositions || 0}</b></div>
        <div><span>Next buy</span><b>{usd(data?.newPositionNotional)}</b></div>
        <div><span>Win rate</span><b>{pct((data?.dbSummary?.winRate || 0) * 100)}</b></div>
        <div><span>Dynamic universe</span><b>{data?.autoUniverse?.activeSymbols?.length || 0}/{data?.autoUniverse?.size || 0}</b></div>
        <div><span>Musk Mode</span><b className={muskModeOn ? "gain" : ""}>{muskModeOn ? "ON" : "OFF"}</b></div>
        <div><span>Musk Hold</span><b className={spaceXHoldOn ? "gain" : ""}>{spaceXHoldOn ? "ON" : "OFF"}</b></div>
        <div><span>Manual picks</span><b>{data?.autoUniverse?.manualPickCount || data?.manualUniversePicks?.length || 0}</b></div>
      </div></Card>

      {!simpleView && <> 

      <Card title="Musk Mode">
        <div className="summary">
          <div><span>Status</span><b className={muskModeOn ? "gain" : ""}>{muskModeOn ? "ON" : "OFF"}</b></div>
          <div><span>Focus list</span><b>{(muskMode?.activeSymbols || []).join(", ") || "TSLA focus"}</b></div>
        </div>
        <div className="actions">
          <button className={muskModeOn ? "active" : "ghost"} onClick={()=>saveMuskMode(true)} disabled={muskModeSaving}>Musk Mode ON</button>
          <button className={!muskModeOn ? "active" : "ghost"} onClick={()=>saveMuskMode(false)} disabled={muskModeSaving}>Musk Mode OFF</button>
        </div>
        <div className="summary">
          <div><span>Musk Hold</span><b className={spaceXHoldOn ? "gain" : ""}>{spaceXHoldOn ? "ON" : "OFF"}</b></div>
          <div><span>Held symbols</span><b>{(spaceXHold?.symbols || muskMode?.activeSymbols || ["SPCX"]).join(", ")}</b></div>
        </div>
        <div className="actions">
          <button className={spaceXHoldOn ? "active" : "ghost"} onClick={()=>saveSpaceXHold(true)} disabled={spacexHoldSaving}>Hold Musk Stocks ON</button>
          <button className={!spaceXHoldOn ? "active" : "ghost"} onClick={()=>saveSpaceXHold(false)} disabled={spacexHoldSaving}>Hold Musk Stocks OFF</button>
        </div>
        <p className="muted">Musk Mode focuses the universe on TSLA/SPCX and related liquid tech names. Musk Hold blocks automatic partial profit, trailing profit, stall, stop/rotation sells for every Musk Mode symbol until you turn hold off or use manual/emergency sell.</p>
      </Card>

      <Card title="Dynamic Market Scanner" wide>
        <div className="summary">
          <div><span>Status</span><b className={dynamicScanner?.enabled === false ? "loss" : "gain"}>{dynamicScanner?.enabled === false ? "OFF" : "ON"}</b></div>
          <div><span>Discovered picks</span><b>{dynamicPickCount}</b></div>
          <div><span>Source</span><b>{dynamicScanner?.source || "market movers"}</b></div>
          <div><span>Refresh</span><b>{dynamicScanner?.updatedAt ? new Date(dynamicScanner.updatedAt).toLocaleTimeString() : "Waiting"}</b></div>
        </div>
        <div className="actions"><button className="purple" onClick={refreshDynamicScanner}>Refresh Dynamic Market</button></div>
        <p className="muted">This searches market movers/active stocks first, applies price/volume/spread filters, then merges the best candidates with your manual pinned stocks and core safety list.</p>
        {dynamicScanner?.error && <p className="notice danger-text">Scanner warning: {dynamicScanner.error}</p>}
        <div className="scan-grid">{dynamicRows.slice(0,12).map((r:AnyObj) => <article className="scan" key={r.symbol}><div><b>{r.symbol}</b><strong>Score {Number(r.score || 0).toFixed(2)}</strong></div><p>{r.reason || "dynamic candidate"}</p><small>{r.price ? `Price ${usd(r.price)} · ` : ""}{r.changePct !== undefined ? `Change ${pct(r.changePct)} · ` : ""}{r.volume ? `Volume ${Number(r.volume).toLocaleString()}` : ""}</small></article>)}</div>
      </Card>

      <Card title="Profit Banking / Trading Cap">
        <div className="summary">
          <div><span>Status</span><b className={bankingEnabled ? "gain" : ""}>{bankingEnabled ? "ON" : "OFF"}</b></div>
          <div><span>Trading cap</span><b>{gbp(bankingCapGbp)} · {usd(bankingCap)}</b></div>
          <div><span>Used for sizing</span><b>{gbp(bankingEffectiveGbp)} · {usd(bankingEffective)}</b></div>
          <div><span>Banked buffer</span><b className="gain">{gbp(bankingBufferGbp)} · {usd(bankingBuffer)}</b></div>
        </div>
        <label className="field"><span>Change trading cap (£)</span><input value={tradingCapInput} onChange={e=>setTradingCapInput(e.target.value)} placeholder="200" inputMode="decimal" /></label>
        <div className="actions">
          <button className="ghost" onClick={()=>{setTradingCapInput("100"); saveTradingCap(100)}} disabled={tradingCapSaving}>£100</button>
          <button className="ghost" onClick={()=>{setTradingCapInput("200"); saveTradingCap(200)}} disabled={tradingCapSaving}>£200</button>
          <button className="ghost" onClick={()=>{setTradingCapInput("260"); saveTradingCap(260)}} disabled={tradingCapSaving}>£260</button>
          <button onClick={()=>saveTradingCap()} disabled={tradingCapSaving}>{tradingCapSaving ? "Saving..." : "Save Cap"}</button>
        </div>
        <p className="muted">Saved cap source: {bankingCapSource}. Profits above the cap stay as cash buffer instead of increasing future trade size.</p>
      </Card>
      <Card title="Trading Strictness">
        <div className="summary">
          <div><span>Mode</span><b>{strategySettings?.label || strictnessLabel}</b></div>
          <div><span>A+ confidence</span><b>{Number(strategySettings?.aPlusMinConfidence ?? data?.aPlusMinConfidence ?? 0).toFixed(2)}</b></div>
          <div><span>Sniper confidence</span><b>{Number(strategySettings?.sniperMinConfidence ?? data?.config?.sniperMinConfidence ?? 0).toFixed(2)}</b></div>
        </div>
        <label className="field">
          <span>Safe ← Balanced → Aggressive</span>
          <input
            type="range"
            min="0"
            max="2"
            step="1"
            value={strategyStrictness}
            onChange={e=>setStrategyStrictness(Number(e.target.value))}
          />
        </label>
        <div className="actions">
          <button className="ghost" onClick={()=>{setStrategyStrictness(0); saveStrategyStrictness(0)}} disabled={strategySaving}>Safe</button>
          <button className="ghost" onClick={()=>{setStrategyStrictness(1); saveStrategyStrictness(1)}} disabled={strategySaving}>Balanced</button>
          <button className="ghost" onClick={()=>{setStrategyStrictness(2); saveStrategyStrictness(2)}} disabled={strategySaving}>Aggressive</button>
          <button onClick={()=>saveStrategyStrictness()} disabled={strategySaving}>{strategySaving ? "Saving..." : `Save ${strictnessLabel}`}</button>
        </div>
        <p className="muted">Safe is more selective. Balanced should allow more trades. Aggressive loosens the confidence gates further without removing risk checks.</p>
      </Card>
      <Card title="Max Positions">
        <div className="summary">
          <div><span>Current limit</span><b>{Number(positionSettings?.maxPositions ?? data?.maxPositions ?? 0)}</b></div>
          <div><span>Open positions</span><b>{positions.length}</b></div>
          <div><span>Allowed new</span><b>{Number(data?.allowedNewPositions ?? 0)}</b></div>
        </div>
        <label className="field">
          <span>Choose maximum open positions</span>
          <input
            type="range"
            min="1"
            max="10"
            step="1"
            value={maxPositionsInput}
            onChange={e=>setMaxPositionsInput(Number(e.target.value))}
          />
        </label>
        <div className="actions">
          <button className="ghost" onClick={()=>{setMaxPositionsInput(2); saveMaxPositions(2)}} disabled={positionsSaving}>2</button>
          <button className="ghost" onClick={()=>{setMaxPositionsInput(4); saveMaxPositions(4)}} disabled={positionsSaving}>4</button>
          <button className="ghost" onClick={()=>{setMaxPositionsInput(6); saveMaxPositions(6)}} disabled={positionsSaving}>6</button>
          <button onClick={()=>saveMaxPositions()} disabled={positionsSaving}>{positionsSaving ? "Saving..." : `Save ${maxPositionsInput}`}</button>
        </div>
        <p className="muted">Lower numbers concentrate the bot into fewer holdings. If you already hold more than the new limit, the bot will stop opening new positions until holdings drop below it.</p>
      </Card>

      <Card title="Buy Size Mode">
        <div className="summary">
          <div><span>Current mode</span><b>{buySizeMode === "full" ? "Full Buy" : "Partial Buy"}</b></div>
          <div><span>Partial estimate</span><b>{gbp(Number((data.buySizePreview || data.positionSettings?.buySizePreview || {}).partialUsd || 0) * rate)} / {usd(Number((data.buySizePreview || data.positionSettings?.buySizePreview || {}).partialUsd || 0))}</b></div>
          <div><span>Full estimate</span><b>{gbp(Number((data.buySizePreview || data.positionSettings?.buySizePreview || {}).fullUsd || 0) * rate)} / {usd(Number((data.buySizePreview || data.positionSettings?.buySizePreview || {}).fullUsd || 0))}</b></div>
          <div><span>Capped equity</span><b>{gbp(Number((data.buySizePreview || data.positionSettings?.buySizePreview || {}).cappedEquityUsd || 0) * rate)} / {usd(Number((data.buySizePreview || data.positionSettings?.buySizePreview || {}).cappedEquityUsd || 0))}</b></div>
        </div>
        <div className="actions">
          <button className={buySizeMode === "partial" ? "active" : "ghost"} onClick={()=>saveBuySizeMode("partial")}>Partial Buy</button>
          <button className={buySizeMode === "full" ? "active" : "ghost"} onClick={()=>saveBuySizeMode("full")}>Full Buy</button>
        </div>
        <p className="muted">Full Buy uses most available capped capital for one position. Partial Buy splits capital across several smaller positions.</p>
      </Card>

      <Card title="Universe Sources" wide>
        <p className="muted">This is now split properly: live scanner picks are current market movers, stock memory is historical performance, and final bot universe is what the bot can actually trade.</p>
        <div className="universe-counts">
          <div><span>Final universe</span><b>{data?.autoUniverse?.activeSymbols?.length || 0}</b></div>
          <div><span>Mode</span><b>{data?.autoUniverse?.mode || (muskModeOn ? "musk-focus" : "quality")}</b></div>
          <div><span>Live scanner picks</span><b>{(data?.autoUniverse?.liveScannerRows || data?.dynamicMarketScanner?.rows || []).length}</b></div>
          <div><span>Stock memory picks</span><b>{(data?.autoUniverse?.memoryRows || []).length}</b></div>
          <div><span>Manual picks</span><b>{data?.autoUniverse?.manualPickCount || data?.manualUniversePicks?.length || 0}</b></div>
        </div>

        <h3>Live Scanner Picks</h3>
        <p className="muted">Pulled from Yahoo market movers / most active / small-cap screens, then filtered by price, volume and spread.</p>
        <div className="scan-grid">{(data?.autoUniverse?.liveScannerRows || data?.dynamicMarketScanner?.rows || []).slice(0,20).map((r:AnyObj) => <article className="scan" key={`live-${r.symbol}`}><div><b>{r.symbol}</b><strong>Live ⚡ {Number(r.score || 0).toFixed(2)}</strong></div><p>{r.reason || "live market scanner candidate"}</p></article>)}{!(data?.autoUniverse?.liveScannerRows || data?.dynamicMarketScanner?.rows || []).length && <p className="muted">No live scanner rows yet. Press Dynamic Market Refresh.</p>}</div>

        <h3>Stock Memory Picks</h3>
        <p className="muted">Pulled from closed-trade history. These are not the live scanner; they show where the bot has historically performed well or badly.</p>
        <div className="scan-grid">{(data?.autoUniverse?.memoryRows || []).slice(0,20).map((r:AnyObj) => <article className="scan" key={`memory-${r.symbol}`}><div><b>{r.symbol}</b><strong>Memory 🧠 {Number(r.score || 0).toFixed(2)}</strong></div><p>{r.reason || "stock memory performance"}</p></article>)}{!(data?.autoUniverse?.memoryRows || []).length && <p className="muted">No stock memory rows yet.</p>}</div>

        <h3>Final Bot Universe</h3>
        <p className="muted">This is the final merged list the backend is actually allowed to trade after manual pins, live scanner, Musk Mode and quality fallback rules.</p>
        <div className="scan-grid">{(data?.autoUniverse?.finalRows || data?.autoUniverse?.rows || []).slice(0,40).map((r:AnyObj) => <article className="scan" key={`final-${r.symbol}`}><div><b>{r.symbol}</b><strong>{r.manualPick ? "Manual ⭐" : r.dynamicPick ? "Live ⚡" : `Score ${Number(r.score || 0).toFixed(2)}`}</strong></div><p>{r.reason || "final tradable universe"}</p></article>)}</div>
      </Card>
      </>}
    </main>}

    {tab==="reports" && <main className="reports-page">
      <div className="actions report-actions"><button onClick={() => fetchData(true)}>Refresh Reports</button><button className="danger" onClick={resetBaseline}>Reset PnL Baseline</button>
          <input
            className="input"
            placeholder="Baseline £ e.g. 989.86"
            value={manualBaselineInput}
            onChange={e=>setManualBaselineInput(e.target.value)}
          />
          <button onClick={setManualBaseline} disabled={baselineSaving}>
            {baselineSaving ? "Saving..." : "Set Manual Baseline"}
          </button></div>
      <section className="stats">
        <Stat label="Deposited" value={gbp(totalDeposited * rate)} sub={`${usd(totalDeposited)} · ${reports.depositSource ? `Source: ${reports.depositSource}` : ""}`} />
        <Stat label="Earned Since Deposit" value={gbp(earned * rate)} sub={usd(earned)} className={tone(earned)} />
        <Stat label="Lost Since Deposit" value={gbp(lost * rate)} sub={usd(lost)} className="loss" />
        <Stat label="Current Equity" value={gbp(Number((reports.currentEquity ?? data?.account?.equity) || 0) * rate)} sub={usd(reports.currentEquity ?? data?.account?.equity)} />
      </section>
      <Card title="Price / Equity History"><div className="chart-controls"><button className={chartCurrency==="GBP" ? "active":""} onClick={() => setChartCurrency("GBP")}>GBP</button><button className={chartCurrency==="USD" ? "active":""} onClick={() => setChartCurrency("USD")}>USD</button></div><div className="chart">{reportChart.length ? <ResponsiveContainer width="100%" height="100%"><AreaChart data={reportChart}><CartesianGrid strokeDasharray="3 3" stroke="#263450"/><XAxis dataKey="label" stroke="#94a3b8" minTickGap={28}/><YAxis stroke="#94a3b8"/><Tooltip formatter={(v:any) => chartCurrency==="GBP" ? gbp(v) : usd(v)}/><Area type="monotone" dataKey="equity" stroke="#38bdf8" fill="#38bdf833"/></AreaChart></ResponsiveContainer> : <p className="muted">No price/equity history yet.</p>}</div></Card>
      <Card title="Daily PnL"><div className="chart small-chart">{dailyPnlChart.length ? <ResponsiveContainer width="100%" height="100%"><BarChart data={dailyPnlChart}><CartesianGrid strokeDasharray="3 3" stroke="#263450"/><XAxis dataKey="day" stroke="#94a3b8"/><YAxis stroke="#94a3b8"/><Tooltip formatter={(v:any) => chartCurrency==="GBP" ? gbp(v) : usd(v)}/><Bar dataKey="pnl" fill="#38bdf8"/></BarChart></ResponsiveContainer> : <p className="muted">Daily PnL bars will appear as trades are recorded.</p>}</div></Card>
      <Card title="Backtest / Paper Replay" wide>
        <p className="muted">Run a quick report using your closed trade history and a chosen trading cap. This does not place trades.</p>
        <label className="field"><span>Replay trading cap (£)</span><input value={replayCapInput} onChange={e=>setReplayCapInput(e.target.value)} placeholder="200" inputMode="decimal" /></label>
        <div className="actions">
          <button className="ghost" onClick={()=>setReplayCapInput("100")}>£100</button>
          <button className="ghost" onClick={()=>setReplayCapInput("200")}>£200</button>
          <button className="ghost" onClick={()=>setReplayCapInput("260")}>£260</button>
          <button onClick={runBacktestReplay} disabled={replayLoading}>{replayLoading ? "Running..." : "Run Replay Report"}</button>
        </div>
        {replayResult && <div className="summary">
          <div><span>Trades tested</span><b>{replayResult?.tradesTested || 0}</b></div>
          <div><span>Win rate</span><b>{pct(Number(replayResult?.winRate || 0) * 100)}</b></div>
          <div><span>Replay PnL</span><b className={tone(replayResult?.replayPnlGbp)}>{gbp(replayResult?.replayPnlGbp)} · {usd(replayResult?.replayPnlUsd)}</b></div>
          <div><span>Best symbol</span><b>{replayResult?.bestSymbol || "—"}</b></div>
          <div><span>Worst symbol</span><b>{replayResult?.worstSymbol || "—"}</b></div>
          <div><span>Max drawdown</span><b className="loss">{gbp(replayResult?.maxDrawdownGbp)}</b></div>
        </div>}
        {replayResult?.notes && <p className="notice">{replayResult.notes}</p>}
        {Array.isArray(replayResult?.bySymbol) && replayResult.bySymbol.length > 0 && <div className="table-wrap"><table><thead><tr><th>Symbol</th><th>Trades</th><th>Win rate</th><th>PnL</th></tr></thead><tbody>{replayResult.bySymbol.slice(0,12).map((r:AnyObj)=><tr key={r.symbol}><td>{r.symbol}</td><td>{r.trades}</td><td>{pct(Number(r.winRate || 0) * 100)}</td><td className={tone(r.pnlGbp)}>{gbp(r.pnlGbp)} / {usd(r.pnlUsd)}</td></tr>)}</tbody></table></div>}
      </Card>
      <Card title="Closed Trade History"><div className="table-wrap"><table><thead><tr><th>Time</th><th>Symbol</th><th>Entry</th><th>Exit</th><th>Qty</th><th>PnL</th><th>%</th></tr></thead><tbody>{closedTrades.slice(-80).reverse().map((t:AnyObj,i:number)=><tr key={i}><td>{t.time || "—"}</td><td>{t.symbol}</td><td>{usd(t.entryPrice)}</td><td>{usd(t.exitPrice)}</td><td>{Number(t.qty || 0).toFixed(4)}</td><td className={tone(t.pnl)}>{gbp(Number(t.pnl || 0) * rate)} / {usd(t.pnl)}</td><td className={tone(t.pnl)}>{pct(t.pnlPct)}</td></tr>)}{!closedTrades.length && <tr><td colSpan={7}>No matched closed trades yet.</td></tr>}</tbody></table></div></Card>
    </main>}

    {tab==="positions" && <Card title="All Positions — Best to Worst"><p className="muted">Sorted by PnL %, strongest winners glow green and weakest positions glow orange/red.</p><div className="position-list">{positions.map((p:AnyObj)=><article className="position" key={p.symbol} style={positionGlowStyle(p)}><div><h3>{p.symbol}</h3><p>Qty {Number(p.qty || 0).toFixed(4)} · Entry {usd(p.entry)} · Price {usd(p.price)}</p><p>Value <b>{gbp(p.marketValueGbp ?? p.marketValue * rate)}</b> / {usd(p.marketValue)}</p></div><div className="position-side"><b className={tone(p.pnl)}>PnL {gbp(p.pnlGbp ?? p.pnl * rate)} / {usd(p.pnl)} / {pct(p.pnlPct)}</b><span>{p.trailingActive ? `Trailing floor ${usd(p.trailFloor)}` : `Trail starts ${usd(p.trailStartPrice)}`}</span><button className="danger" onClick={() => action(`/sell/${p.symbol}`)}>Sell {p.symbol}</button></div></article>)}{!positions.length && <p className="muted">No open positions.</p>}</div></Card>}

    {tab==="scanner" && <main><Card title="Scanner Price History">{scans.length>0 && <select value={selectedSymbol} onChange={e=>setSelectedSymbol(e.target.value)}>{scans.map((s:AnyObj)=><option key={s.symbol}>{s.symbol}</option>)}</select>}<div className="chart">{scannerChart.length ? <ResponsiveContainer width="100%" height="100%"><LineChart data={scannerChart}><CartesianGrid strokeDasharray="3 3" stroke="#263450"/><XAxis dataKey="t" stroke="#94a3b8"/><YAxis stroke="#94a3b8"/><Tooltip/><Line type="monotone" dataKey="value" stroke="#38bdf8" dot={false}/></LineChart></ResponsiveContainer> : <p className="muted">No scanner price history yet.</p>}</div></Card></main>}

    {tab==="search" && <main><Card title="Stock Search / Preview"><div className="search-row"><input value={stockQuery} onChange={e=>{setStockQuery(e.target.value); if(e.target.value.trim().length>=2) searchStocks(e.target.value); if(!e.target.value.trim()) setStockResults([])}} onKeyDown={e=>{if(e.key==="Enter") searchStocks()}} placeholder="Search ticker or company, e.g. AMD"/><button onClick={()=>searchStocks()}>{stockSearchLoading ? "Searching..." : "Search"}</button></div><div className="search-results">{stockResults.map((s:AnyObj)=><article className="search-card" key={s.symbol}><div className="search-main"><div className="logo-circle">{s.symbol.slice(0,2)}</div><div><h3>{s.name}</h3><p>{s.symbol} · NASDAQ/NYSE</p></div></div><div className="search-price"><strong>{usd(s.price)}</strong><span className={tone(s.changePct)}>{Number(s.changePct || 0)>=0 ? "↗":"↘"} {pct(s.changePct)}</span><small>{gbp(s.priceGbp)}</small></div><div className="mini-chart">{Array.isArray(s.history) && s.history.length>1 ? <ResponsiveContainer width="100%" height="100%"><LineChart data={s.history.map((p:AnyObj,i:number)=>({...p,i}))}><Line type="monotone" dataKey="value" stroke="#38bdf8" dot={false} strokeWidth={2}/><Tooltip formatter={(v:any)=>usd(v)}/></LineChart></ResponsiveContainer> : <p className="muted">Preview builds while you search.</p>}</div><div className="search-actions"><button onClick={()=>action(`/custom-buy/${s.symbol}`)}>Buy</button><button className="ghost" onClick={()=>action(`/add-to-universe/${s.symbol}`)}>Add to Universe</button><button className="danger" onClick={()=>action(`/remove-from-universe/${s.symbol}`)}>Remove</button></div></article>)}{!stockResults.length && <p className="muted">Type a symbol to preview price, daily movement and mini chart.</p>}</div></Card></main>}

    {tab==="activity" && <main className="grid two"><Card title="Recent Trades"><div className="log-list">{trades.slice(-50).reverse().map((t:AnyObj,i:number)=><div key={i}>{t.time || "—"} · <b>{t.side} {t.symbol}</b> · {t.reason || ""}</div>)}{!trades.length && <p className="muted">No trades yet.</p>}</div></Card><Card title="Logs"><div className="log-list">{logs.map((l:string,i:number)=><div key={i}>{l}</div>)}</div></Card></main>}

    {tab==="admin" && <Card title="Admin"><label className="field"><span>Dashboard password</span><input type="password" value={apiKey} onChange={e=>setApiKey(e.target.value)}/></label><div className="actions"><button onClick={saveApiKey}>Save</button><button className="ghost" onClick={()=>{localStorage.removeItem("dashboard_api_key"); setApiKey("")}}>Clear</button></div><pre>{JSON.stringify({ api:API_URL, botEnabled:data?.botEnabled, market:data?.market, manualPicks:data?.manualUniversePicks, tradingCapGbp:bankingCapGbp, tradingCapSource:bankingCapSource }, null, 2)}</pre></Card>}
  </div>;
}
